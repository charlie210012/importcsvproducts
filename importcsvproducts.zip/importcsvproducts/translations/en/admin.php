<?php
$_MODULE['<{importcsvproducts}prestashop>admin'] = 'Import CSV Products';
$_MODULE['<{importcsvproducts}prestashop>admin'] = 'Import products from a CSV file.';
$_MODULE['<{importcsvproducts}prestashop>admin'] = 'Product imported: %s';
$_MODULE['<{importcsvproducts}prestashop>admin'] = 'Error importing product: %s';
$_MODULE['<{importcsvproducts}prestashop>admin'] = 'CSV file not found.';
